import tkinter as tk
from tkinter import ttk, messagebox
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import yfinance as yf
from datetime import datetime
import threading
import time
from collections import defaultdict
import json
import os

CONFIG_FILE = "stock_monitor_config.json"

class StockMonitorApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Multi-Stock Price Monitor")
        self.root.geometry("1200x820")

        # Data storage
        self.times = defaultdict(list)
        self.prices = defaultdict(list)
        self.last_prices = {}                 # symbol -> most recent price
        self.running = False
        self.high_alerted = defaultdict(bool)
        self.low_alerted = defaultdict(bool)
        self.symbols = []
        self.lines = {}
        self.axes = {}
        self.canvases = {}
        self.chart_frames = {}
        self.colors = plt.cm.tab10.colors
        self.saved_alerts = {}
        self.percent_labels = {}              # symbol -> {"high": Label, "low": Label}

        # --- Controls frame ---
        control_frame = ttk.LabelFrame(root, text="Controls", padding="10")
        control_frame.pack(fill=tk.X, padx=10, pady=5)

        ttk.Label(control_frame, text="Tickers (comma-separated):").grid(row=0, column=0, padx=5, pady=5, sticky="e")
        self.ticker_entry = ttk.Entry(control_frame, width=35)
        self.ticker_entry.grid(row=0, column=1, padx=5, pady=5, sticky="w")

        self.update_btn = ttk.Button(control_frame, text="Update", command=self.update_symbols)
        self.update_btn.grid(row=0, column=2, padx=5, pady=5)

        ttk.Label(control_frame, text="Interval (sec):").grid(row=1, column=0, padx=5, pady=5, sticky="e")
        self.interval_entry = ttk.Entry(control_frame, width=8)
        self.interval_entry.insert(0, "5")
        self.interval_entry.grid(row=1, column=1, padx=5, pady=5, sticky="w")

        self.start_btn = ttk.Button(control_frame, text="Start", command=self.start)
        self.start_btn.grid(row=0, column=3, rowspan=2, padx=10, pady=5)

        self.stop_btn = ttk.Button(control_frame, text="Stop", command=self.stop, state=tk.DISABLED)
        self.stop_btn.grid(row=0, column=4, rowspan=2, padx=5, pady=5)

        self.status_label = ttk.Label(control_frame, text="Status: Stopped", font=("Arial", 10, "bold"))
        self.status_label.grid(row=2, column=0, columnspan=5, pady=5)

        # --- Per-stock alert settings ---
        self.alerts_frame = ttk.LabelFrame(root, text="Alert Levels (leave blank to disable)", padding="10")
        self.alerts_frame.pack(fill=tk.X, padx=10, pady=5)
        self.alert_entries = {}

        # --- Current prices display ---
        self.prices_frame = ttk.LabelFrame(root, text="Current Prices", padding="10")
        self.prices_frame.pack(fill=tk.X, padx=10, pady=5)
        self.price_labels = {}

        # --- Scrollable charts area ---
        charts_container = ttk.LabelFrame(root, text="Charts", padding="5")
        charts_container.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)

        self.canvas_scroll = tk.Canvas(charts_container)
        scrollbar = ttk.Scrollbar(charts_container, orient="vertical", command=self.canvas_scroll.yview)
        self.charts_frame = ttk.Frame(self.canvas_scroll)

        self.charts_frame.bind(
            "<Configure>",
            lambda e: self.canvas_scroll.configure(scrollregion=self.canvas_scroll.bbox("all"))
        )

        self.canvas_scroll.create_window((0, 0), window=self.charts_frame, anchor="nw")
        self.canvas_scroll.configure(yscrollcommand=scrollbar.set)

        self.canvas_scroll.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        self.canvas_scroll.bind_all("<MouseWheel>", self._on_mousewheel)

        self.load_config()

    def _on_mousewheel(self, event):
        self.canvas_scroll.yview_scroll(int(-1 * (event.delta / 120)), "units")

    def load_config(self):
        if os.path.exists(CONFIG_FILE):
            try:
                with open(CONFIG_FILE, "r") as f:
                    config = json.load(f)
                tickers = config.get("tickers", [])
                interval = config.get("interval", 5)
                self.saved_alerts = config.get("alerts", {})

                if tickers:
                    self.ticker_entry.delete(0, tk.END)
                    self.ticker_entry.insert(0, ", ".join(tickers))

                self.interval_entry.delete(0, tk.END)
                self.interval_entry.insert(0, str(interval))
            except Exception as e:
                print(f"Could not load config: {e}")
                self.saved_alerts = {}
        else:
            self.saved_alerts = {}

    def save_config(self):
        try:
            self.capture_current_alerts()
            interval = self.get_interval()
            config = {
                "tickers": self.symbols.copy() if self.symbols else [
                    s.strip().upper() for s in self.ticker_entry.get().split(",") if s.strip()
                ],
                "interval": interval,
                "alerts": self.saved_alerts
            }
            with open(CONFIG_FILE, "w") as f:
                json.dump(config, f, indent=2)
        except Exception as e:
            print(f"Could not save config: {e}")

    def capture_current_alerts(self):
        for symbol, entries in self.alert_entries.items():
            self.saved_alerts[symbol] = {
                "high": entries["high"].get().strip(),
                "low": entries["low"].get().strip()
            }

    def rebuild_alert_ui(self):
        for widget in self.alerts_frame.winfo_children():
            widget.destroy()
        self.alert_entries.clear()
        self.percent_labels.clear()

        if not self.symbols:
            return

        # Headers
        ttk.Label(self.alerts_frame, text="Symbol", font=("Arial", 9, "bold")).grid(row=0, column=0, padx=5, pady=2)
        ttk.Label(self.alerts_frame, text="High Alert", font=("Arial", 9, "bold")).grid(row=0, column=1, padx=5, pady=2)
        ttk.Label(self.alerts_frame, text="High %", font=("Arial", 9, "bold")).grid(row=0, column=2, padx=5, pady=2)
        ttk.Label(self.alerts_frame, text="Low Alert", font=("Arial", 9, "bold")).grid(row=0, column=3, padx=5, pady=2)
        ttk.Label(self.alerts_frame, text="Low %", font=("Arial", 9, "bold")).grid(row=0, column=4, padx=5, pady=2)

        for i, symbol in enumerate(self.symbols):
            ttk.Label(self.alerts_frame, text=symbol, font=("Arial", 10, "bold")).grid(row=i+1, column=0, padx=5, pady=2)

            high_entry = ttk.Entry(self.alerts_frame, width=10)
            high_entry.grid(row=i+1, column=1, padx=5, pady=2)

            high_pct = ttk.Label(self.alerts_frame, text="--", width=8, font=("Arial", 10, "bold"))
            high_pct.grid(row=i+1, column=2, padx=5, pady=2)

            low_entry = ttk.Entry(self.alerts_frame, width=10)
            low_entry.grid(row=i+1, column=3, padx=5, pady=2)

            low_pct = ttk.Label(self.alerts_frame, text="--", width=8, font=("Arial", 10, "bold"))
            low_pct.grid(row=i+1, column=4, padx=5, pady=2)

            if symbol in self.saved_alerts:
                high_entry.insert(0, self.saved_alerts[symbol].get("high", ""))
                low_entry.insert(0, self.saved_alerts[symbol].get("low", ""))

            self.alert_entries[symbol] = {"high": high_entry, "low": low_entry}
            self.percent_labels[symbol] = {"high": high_pct, "low": low_pct}

            # Refresh percentage when user edits the alert level
            high_entry.bind("<KeyRelease>", lambda e, s=symbol: self.refresh_percentage(s))
            low_entry.bind("<KeyRelease>", lambda e, s=symbol: self.refresh_percentage(s))

            high_entry.bind("<KeyRelease>", lambda e, s=symbol: self.reset_alert(s, "high"), add="+")
            low_entry.bind("<KeyRelease>", lambda e, s=symbol: self.reset_alert(s, "low"), add="+")

        # Update percentages immediately if we already have prices
        for symbol in self.symbols:
            if symbol in self.last_prices:
                self.refresh_percentage(symbol)

    def refresh_percentage(self, symbol):
        """Update the high/low percentage labels for one symbol."""
        if symbol not in self.percent_labels or symbol not in self.last_prices:
            return

        price = self.last_prices[symbol]
        if price is None:
            return

        entries = self.alert_entries.get(symbol)
        if not entries:
            return

        # High percentage
        high_str = entries["high"].get().strip()
        high_lbl = self.percent_labels[symbol]["high"]
        if high_str:
            try:
                high = float(high_str)
                if high > 0:
                    ratio = (price / high) * 100
                    high_lbl.config(text=f"{ratio:.1f}%")
                    if ratio >= 100:
                        high_lbl.config(foreground="green")
                    elif 95 <= ratio < 100:
                        high_lbl.config(foreground="orange")
                    else:
                        high_lbl.config(foreground="red")
                else:
                    high_lbl.config(text="--", foreground="black")
            except ValueError:
                high_lbl.config(text="--", foreground="black")
        else:
            high_lbl.config(text="--", foreground="black")

        # Low percentage
        low_str = entries["low"].get().strip()
        low_lbl = self.percent_labels[symbol]["low"]
        if low_str:
            try:
                low = float(low_str)
                if low > 0:
                    ratio = (price / low) * 100
                    low_lbl.config(text=f"{ratio:.1f}%")
                    if ratio <= 100:
                        low_lbl.config(foreground="green")
                    elif 100 < ratio <= 105:
                        low_lbl.config(foreground="orange")
                    else:
                        low_lbl.config(foreground="red")
                else:
                    low_lbl.config(text="--", foreground="black")
            except ValueError:
                low_lbl.config(text="--", foreground="black")
        else:
            low_lbl.config(text="--", foreground="black")

    def rebuild_price_ui(self):
        for widget in self.prices_frame.winfo_children():
            widget.destroy()
        self.price_labels.clear()

        for i, symbol in enumerate(self.symbols):
            lbl = ttk.Label(self.prices_frame, text=f"{symbol}: --", font=("Arial", 11))
            lbl.grid(row=0, column=i, padx=15, pady=5)
            self.price_labels[symbol] = lbl

    def create_chart_for_symbol(self, symbol):
        frame = ttk.Frame(self.charts_frame)
        frame.pack(fill=tk.X, padx=5, pady=4)
        self.chart_frames[symbol] = frame

        fig, ax = plt.subplots(figsize=(8.5, 2.6))
        ax.set_title(f"{symbol} Price History", fontsize=11)
        ax.set_xlabel("Time")
        ax.set_ylabel("Price")
        ax.grid(True, alpha=0.3)

        color_idx = len(self.lines) % len(self.colors)
        color = self.colors[color_idx]
        line, = ax.plot([], [], color=color, linewidth=1.8)
        self.lines[symbol] = line
        self.axes[symbol] = ax

        canvas = FigureCanvasTkAgg(fig, master=frame)
        canvas.get_tk_widget().pack(fill=tk.X)
        self.canvases[symbol] = canvas
        fig.tight_layout()

        if self.times[symbol] and self.prices[symbol]:
            line.set_data(self.times[symbol], self.prices[symbol])
            ax.set_xlim(self.times[symbol][0], self.times[symbol][-1])
            ymin = min(self.prices[symbol]) * 0.998
            ymax = max(self.prices[symbol]) * 1.002
            ax.set_ylim(ymin, ymax)
            canvas.draw_idle()

    def rebuild_charts(self):
        for widget in self.charts_frame.winfo_children():
            widget.destroy()
        self.lines.clear()
        self.axes.clear()
        self.canvases.clear()
        self.chart_frames.clear()

        for symbol in self.symbols:
            self.create_chart_for_symbol(symbol)

        self.charts_frame.update_idletasks()
        self.canvas_scroll.configure(scrollregion=self.canvas_scroll.bbox("all"))

    def reset_alert(self, symbol, which):
        if which == "high":
            self.high_alerted[symbol] = False
        else:
            self.low_alerted[symbol] = False

    def get_price(self, symbol):
        try:
            ticker = yf.Ticker(symbol)
            price = ticker.fast_info.get("lastPrice") or ticker.fast_info.get("regularMarketPrice")
            if price is None:
                hist = ticker.history(period="1d", interval="1m")
                if not hist.empty:
                    price = float(hist["Close"].iloc[-1])
            return float(price) if price is not None else None
        except Exception as e:
            print(f"Price fetch error for {symbol}: {e}")
            return None

    def update_loop(self):
        while self.running:
            now = datetime.now()
            new_prices = {}

            for symbol in list(self.symbols):
                price = self.get_price(symbol)
                if price is not None:
                    new_prices[symbol] = price

            if new_prices:
                for symbol, price in new_prices.items():
                    self.times[symbol].append(now)
                    self.prices[symbol].append(price)
                    self.last_prices[symbol] = price

                    if len(self.times[symbol]) > 500:
                        self.times[symbol] = self.times[symbol][-500:]
                        self.prices[symbol] = self.prices[symbol][-500:]

                self.root.after(0, self.update_ui, new_prices, now)

            interval = self.get_interval()
            time.sleep(interval)

    def get_interval(self):
        try:
            val = int(self.interval_entry.get())
            return max(1, min(600, val))
        except ValueError:
            return 5

    def update_ui(self, new_prices, timestamp):
        for symbol, price in new_prices.items():
            if symbol in self.price_labels:
                self.price_labels[symbol].config(
                    text=f"{symbol}: ${price:.2f}  ({timestamp.strftime('%H:%M:%S')})"
                )
            # Update percentage displays
            self.refresh_percentage(symbol)

        self.check_alerts(new_prices)

        for symbol in list(self.symbols):
            if symbol not in self.lines or not self.prices[symbol]:
                continue

            line = self.lines[symbol]
            ax = self.axes[symbol]
            times = self.times[symbol]
            prices = self.prices[symbol]

            line.set_data(times, prices)

            if times:
                ax.set_xlim(times[0], times[-1])
                ymin = min(prices) * 0.998
                ymax = max(prices) * 1.002
                ax.set_ylim(ymin, ymax)

            ax.relim()
            ax.autoscale_view()
            if symbol in self.canvases:
                self.canvases[symbol].draw_idle()

    def check_alerts(self, new_prices):
        for symbol, price in new_prices.items():
            if symbol not in self.alert_entries:
                continue

            try:
                high_str = self.alert_entries[symbol]["high"].get().strip()
                low_str = self.alert_entries[symbol]["low"].get().strip()
                high = float(high_str) if high_str else None
                low = float(low_str) if low_str else None
            except ValueError:
                continue

            if high is not None and price >= high and not self.high_alerted[symbol]:
                self.root.bell()
                self.status_label.config(
                    text=f"HIGH ALERT: {symbol} ${price:.2f} >= ${high:.2f}",
                    foreground="red"
                )
                self.high_alerted[symbol] = True
                print(f"[HIGH] {symbol} reached {price:.2f}")

            if low is not None and price <= low and not self.low_alerted[symbol]:
                self.root.bell()
                self.status_label.config(
                    text=f"LOW ALERT: {symbol} ${price:.2f} <= ${low:.2f}",
                    foreground="blue"
                )
                self.low_alerted[symbol] = True
                print(f"[LOW] {symbol} reached {price:.2f}")

            if high is not None and price < high:
                self.high_alerted[symbol] = False
            if low is not None and price > low:
                self.low_alerted[symbol] = False

    def update_symbols(self):
        self.capture_current_alerts()

        raw = self.ticker_entry.get().strip()
        new_symbols = [s.strip().upper() for s in raw.split(",") if s.strip()]

        if not new_symbols:
            messagebox.showwarning("Update", "Please enter at least one ticker.")
            return

        seen = set()
        new_symbols = [s for s in new_symbols if not (s in seen or seen.add(s))]

        old_set = set(self.symbols)
        new_set = set(new_symbols)

        to_add = [s for s in new_symbols if s not in old_set]
        to_remove = [s for s in self.symbols if s not in new_set]

        for symbol in to_remove:
            if symbol in self.symbols:
                self.symbols.remove(symbol)
            if symbol in self.chart_frames:
                self.chart_frames[symbol].destroy()
                del self.chart_frames[symbol]
            self.lines.pop(symbol, None)
            self.axes.pop(symbol, None)
            self.canvases.pop(symbol, None)

        for symbol in to_add:
            if symbol not in self.symbols:
                self.symbols.append(symbol)
            self.create_chart_for_symbol(symbol)

        self.rebuild_alert_ui()
        self.rebuild_price_ui()

        self.charts_frame.update_idletasks()
        self.canvas_scroll.configure(scrollregion=self.canvas_scroll.bbox("all"))

        self.save_config()

        added_msg = f"Added: {', '.join(to_add)}" if to_add else ""
        removed_msg = f"Removed: {', '.join(to_remove)}" if to_remove else ""
        msg = " | ".join(filter(None, [added_msg, removed_msg])) or "No changes"
        self.status_label.config(text=f"Updated symbols. {msg}", foreground="green")

    def start(self):
        raw = self.ticker_entry.get().strip()
        if not raw:
            messagebox.showerror("Error", "Please enter at least one ticker")
            return

        symbols = [s.strip().upper() for s in raw.split(",") if s.strip()]
        if not symbols:
            messagebox.showerror("Error", "No valid tickers found")
            return

        seen = set()
        symbols = [s for s in symbols if not (s in seen or seen.add(s))]

        try:
            interval = int(self.interval_entry.get())
            if not (1 <= interval <= 600):
                raise ValueError
        except ValueError:
            messagebox.showerror("Error", "Interval must be an integer between 1 and 600 seconds")
            return

        self.symbols = symbols
        for symbol in list(self.times.keys()):
            if symbol not in symbols:
                del self.times[symbol]
                del self.prices[symbol]

        self.high_alerted.clear()
        self.low_alerted.clear()

        self.running = True
        self.rebuild_alert_ui()
        self.rebuild_price_ui()
        self.rebuild_charts()

        self.save_config()

        self.start_btn.config(state=tk.DISABLED)
        self.stop_btn.config(state=tk.NORMAL)
        self.update_btn.config(state=tk.NORMAL)
        self.status_label.config(
            text=f"Monitoring {len(symbols)} stock(s) every {interval}s",
            foreground="green"
        )

        thread = threading.Thread(target=self.update_loop, daemon=True)
        thread.start()

    def stop(self):
        self.running = False
        self.save_config()
        self.start_btn.config(state=tk.NORMAL)
        self.stop_btn.config(state=tk.DISABLED)
        self.status_label.config(text="Status: Stopped", foreground="black")

if __name__ == "__main__":
    root = tk.Tk()
    app = StockMonitorApp(root)
    root.protocol("WM_DELETE_WINDOW", lambda: (app.stop(), root.destroy()))
    root.mainloop()