@echo off
cd /d "E:\python\apps\StockTracker"

echo Starting Stock Monitor...
python -c "import yfinance, matplotlib" 2>nul
if errorlevel 1 (
    echo Installing required packages...
    pip install yfinance matplotlib
)

python stock_monitor.py

echo.
echo App closed. Press any key to exit...
pause >nul